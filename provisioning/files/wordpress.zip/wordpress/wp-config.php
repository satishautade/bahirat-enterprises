<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '.N&c`Ib}r|NR@|&N/]k +b>W=aLQV%KYXbttUxQ!;,.8<7?Rwc9X/yVQwShK:c2E');
define('SECURE_AUTH_KEY',  ']Q2bE`*,5~Pu4NN|cA=U?OpooUHZp^M4ujVmo6td$-*(Zj`:u0hk1}p$[a:~|uP<');
define('LOGGED_IN_KEY',    'kASr%Gd?=8hkb18D-yeefO]o;F*,eXT&*f^n<Kr=JpX<kE{6nYN=[_VSmSvZ4Vj%');
define('NONCE_KEY',        'F?Tjh1SViOcAWb/vkt{_|nZ2<^y{zeGFo*XtgwmVqW)tn=d5bSTNFw1)u:X7rN9%');
define('AUTH_SALT',        '<BoZx1p[C?%ptXip]}9|xtcJ9v(:>8pC3pRN4mOn$+EBdjCzaDX<J48<8j+69fS3');
define('SECURE_AUTH_SALT', '_xQEJH2S<ZL..U.grF*_M2n0ISIIL&?hB=gUkUEi]Zu8+s8Py)5>~S^)`n*K~$qO');
define('LOGGED_IN_SALT',   '9@-=?x*wi/0Y-!L-V,&nbU&F>EygE4Zhd$t&jT+oaORH9hqk5%bW=IXKs*t_|GFK');
define('NONCE_SALT',       '/*DVvcb3UZj,f0R#^!]P2h{M~l/^>r2@e|<M4VD-S5{+du#IjgrNL9?M9&S7_<2M');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp1_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
define( 'WP_MEMORY_LIMIT', '512M' );
